# Auth Screens Mason Brick

A Flutter authentication screens brick with customizable options.

## Features

- Login screen with customizable options
- Signup screen with dynamic form fields
- Forgot password screen with popup option
- Customizable theme
- Form validation
- BLoC pattern for state management
- Clean architecture structure

## Usage

```bash
# Install the brick
mason add auth_screens

# Create a new project with the brick
mason make auth_screens
```

## Customization Options

### Login Page
- Show/hide app bar
- Show/hide forgot password option
- Customize submit button text

### Signup Page
- Show/hide app bar
- Customize submit button text
- Configure form fields:
  - Name
  - Type (text, email, password, phone, number, date, time, datetime, url, multiline)
  - Required/Optional
  - Custom validation message
  - Placeholder text

### Forgot Password
- Show as popup or full screen
- Customize submit button text

### Theme
- Primary color
- Secondary color
- Background color
- Error color
- Text color
- Label color

## Project Structure

```
lib/
  ├── features/
  │   └── auth/
  │       ├── data/
  │       │   └── repositories/
  │       │       └── auth_repository_impl.dart
  │       ├── domain/
  │       │   ├── entities/
  │       │   │   └── user.dart
  │       │   ├── repositories/
  │       │   │   └── auth_repository.dart
  │       │   └── usecases/
  │       │       ├── login_usecase.dart
  │       │       ├── signup_usecase.dart
  │       │       └── reset_password_usecase.dart
  │       └── presentation/
  │           ├── bloc/
  │           │   ├── auth_bloc.dart
  │           │   ├── auth_event.dart
  │           │   └── auth_state.dart
  │           ├── screens/
  │           │   ├── auth_screen.dart
  │           │   ├── login_screen.dart
  │           │   ├── signup_screen.dart
  │           │   └── forgot_password_screen.dart
  │           ├── theme/
  │           │   └── auth_theme.dart
  │           ├── templates/
  │           │   └── auth_template.dart
  │           └── utils/
  │               └── field_validator.dart
  └── main.dart
```

## Dependencies

- flutter_bloc: ^8.1.3
- equatable: ^2.0.5

## License

MIT
