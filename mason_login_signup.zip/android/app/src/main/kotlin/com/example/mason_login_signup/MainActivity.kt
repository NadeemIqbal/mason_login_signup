package com.example.mason_login_signup

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
